package Labs.PracticeExam.LabFifteen;

public class Main {
}
