package Labs.PracticeExam.LabOne;
/*
Write a program that outputs the pattern shown below, ending with a newline. Each line of the pattern contains 5 characters including whitespace.

The output is:

H   H
H   H
HHHHH
H   H
H   H
 */
public class Main {
        public static void main(String[] args) {
            /* Type your code here. */
            System.out.println("H   H");
            System.out.println("H   H");
            System.out.println("HHHHH");
            System.out.println("H   H");
            System.out.println("H   H");
        }
}

