package Labs.PracticeExam.LabThirteen;

public class Main {
}
