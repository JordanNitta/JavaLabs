package Labs.PracticeExam.LabTwelve;

public class Main {
}
